<?php 
/**
 * Templates Name: Elementor
 * Widget: Currency
 */
    
    ?>
        <div <?php echo trim($this->get_render_attribute_string('wrapper')); ?>>
            <?php $this->diza_currency(); ?>
        </div>
    <?php

    
?>